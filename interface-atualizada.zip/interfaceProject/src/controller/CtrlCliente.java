package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlCliente
{   
  public CtrlCliente(int int1, String string, String string2, String string3, String string4) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int matricula, String nome, String contato, String endereco, String situacao) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Cliente_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Cliente(matricula, nome, contato, endereco, situacao) values(?, ?, ?, ?, ?)");
    pstmt.setInt(1, matricula);
    pstmt.setString(2, nome);
    pstmt.setString(3, contato);
    pstmt.setString(4, endereco);
    pstmt.setString(5, situacao);
   
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int matricula, String nome, String contato, String endereco, String situacao) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Cliente set nome = ?, contato = ?, endereco = ?, situacao = ? where matricula = ?");
    pstmt.setInt(1, matricula);
    pstmt.setString(2, nome);
    pstmt.setString(3, contato);
    pstmt.setString(4, endereco);
    pstmt.setString(5, situacao);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, String matricula) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Cliente where matricula = ?");
    pstmt.setString(1, matricula);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlCliente recuperaUmCliente(Connection conn, int matricula)
  { CtrlCliente umCliente = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente where matricula = ?");
      pstmt.setInt(1, matricula);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umCliente = new CtrlCliente(rs.getInt("matricula"),
                                      rs.getString("nome"),
                                      rs.getString("contato"),
                                      rs.getString("endereco"),
                                      rs.getString("situacao"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umCliente;
  }

  public static ArrayList<CtrlCliente> recuperaCliente(Connection conn)
  { ArrayList<CtrlCliente> arrayCliente = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayCliente = new ArrayList<CtrlCliente>(20);
        do
        { arrayCliente.add(new CtrlCliente(rs.getInt("matricula"),
                                      rs.getString("nome"),
                                      rs.getString("contato"),
                                      rs.getString("endereco"),
                                      rs.getString("situacao")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayCliente;
  }
}