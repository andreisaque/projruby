package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlFornecedor
{   
  public CtrlFornecedor(String string, String string2, double double1, String string3, String string4, String string5) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, String cnpj, String razao_social, String nome, String contato,
      String endereco, String descricao) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Fornecedor_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Fornecedor(cnpj, razao_social, nome, contato, endereco, descricao) values(?, ?, ?, ?, ?, ?)");
    pstmt.setString(1, cnpj);
    pstmt.setString(2, razao_social);
    pstmt.setString(3, nome);
    pstmt.setString(4, contato);
    pstmt.setString(5, endereco);
    pstmt.setString(6, descricao);
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, String cnpj, String razao_social, String nome, String contato,
      String endereco, String descricao) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Fornecedor set razao_social = ?, nome = ?, contato = ?, endereco = ?, descricao = ? where cnpj = ?");
    pstmt.setString(1, razao_social);
    pstmt.setString(2, nome);
    pstmt.setString(3, contato);
    pstmt.setString(4, endereco);
    pstmt.setString(5, descricao);
    pstmt.setString(6, cnpj);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, String cnpj) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Fornecedor where cnpj = ?");
    pstmt.setString(1, cnpj);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlFornecedor recuperaUmFornecedor(Connection conn, int cnpj)
  { CtrlFornecedor umFornecedor = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Fornecedor where cnpj = ?");
      pstmt.setInt(1, cnpj);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umFornecedor = new CtrlFornecedor(rs.getString("cnpj"),
                                      rs.getString("razao_social"),
                                      rs.getDouble("nome"),
                                      rs.getString("contato"),
                                      rs.getString("endereco"),
                                      rs.getString("descricao"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umFornecedor;
  }

  public static ArrayList<CtrlFornecedor> recuperaFornecedor(Connection conn)
  { ArrayList<CtrlFornecedor> arrayFornecedor = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Fornecedor");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayFornecedor = new ArrayList<CtrlFornecedor>(20);
        do
        { arrayFornecedor.add(new CtrlFornecedor(rs.getString("cnpj"),
                                             rs.getString("razao_social"),
                                             rs.getDouble("nome"),
                                             rs.getString("contato"),
                                             rs.getString("endereco"),
                                             rs.getString("descricao")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayFornecedor;
  }
}

