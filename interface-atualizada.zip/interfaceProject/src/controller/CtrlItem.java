package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlItem
{   
  public CtrlItem(int int1, String string, String string2, String string3) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int sequencial, int quantidade, int produto_codigo, int pedido_codigo) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Item_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Item(sequencial, quantidade, produto_codigo, pedido_codigo) values(?, ?, ?, ?)");
    pstmt.setInt(1, sequencial);
    pstmt.setInt(2, quantidade);
    pstmt.setInt(3, produto_codigo);
    pstmt.setInt(4, pedido_codigo);
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int sequencial, int quantidade, int produto_codigo, int pedido_codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Item set quantidade = ?, produto_codigo = ? ,pedido_codigo = ? where sequencial = ?");
    pstmt.setInt(1, quantidade);
    pstmt.setInt(2, produto_codigo);
    pstmt.setInt(3, pedido_codigo);
    pstmt.setInt(4, sequencial);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, int sequencial) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Item where sequencial = ?");
    pstmt.setInt(1, sequencial);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlItem recuperaUmItem(Connection conn, int sequencial)
  { CtrlItem umItem = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Item where sequencial = ?");
      pstmt.setInt(1, sequencial);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umItem = new CtrlItem(rs.getInt("sequencial"),
                                  rs.getString("quantidade"),
                                  rs.getString("produto_codigo"),
                                  rs.getString("pedido_codigo"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umItem;
  }

  public static ArrayList<CtrlItem> recuperaItem(Connection conn)
  { ArrayList<CtrlItem> arrayItem = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Item");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayItem = new ArrayList<CtrlItem>(20);
        do
        { arrayItem.add(new CtrlItem(rs.getInt("sequencial"),
                                  rs.getString("quantidade"),
                                  rs.getString("produto_codigo"),
                                  rs.getString("pedido_codigo")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayItem;
  }
}
