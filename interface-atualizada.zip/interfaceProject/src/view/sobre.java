package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.DropMode;
import java.awt.SystemColor;
import javax.swing.border.EtchedBorder;

public class sobre extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sobre frame = new sobre();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public sobre() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 681, 583);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel base = new JPanel();
		base.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		base.setBounds(24, 23, 613, 446);
		contentPane.add(base);
		base.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel_4.setBackground(new Color(72, 61, 139));
		panel_4.setBounds(300, 239, 313, 33);
		base.add(panel_4);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel_2.setBackground(new Color(72, 61, 139));
		panel_2.setBounds(300, 140, 313, 33);
		base.add(panel_2);
		
		JLabel lbl_titulo = new JLabel("Projeto de Programa\u00E7\u00E3o Orientado \u00E0 Objeto");
		lbl_titulo.setForeground(new Color(220, 220, 220));
		lbl_titulo.setBounds(165, 23, 263, 41);
		base.add(lbl_titulo);
		
		JLabel lblEste = new JLabel("<html>\r\n<p> Este projeto foi resultado de muita dedica\u00E7\u00E3o, perseveran\u00E7a e paci\u00EAncia por parte de todos os envolvidos.  <br> Apesar das dores de cabe\u00E7a e muitas noites mal dormidas, valeu a pena. <br></p></html>");
		lblEste.setBounds(12, 71, 589, 56);
		base.add(lblEste);
		
		JLabel lblvictriaBeloAndr = new JLabel("<html><p>Vict\u00F3ria Belo<br>\r\nAndr\u00E9 Isaque </p></html>\r\n\r\n\r\n");
		lblvictriaBeloAndr.setVerticalAlignment(SwingConstants.BOTTOM);
		lblvictriaBeloAndr.setBounds(67, 186, 589, 33);
		base.add(lblvictriaBeloAndr);
		
		JLabel blablablabla = new JLabel("<html><p><br> \r\nGabriel  Apar\u00EDcio <br>\r\nReginaldo Gaio<br>\r\nThe Jeff <br>\r\n\r\n\r\n\r\n</p></html>\r\n\r\n\r\n");
		blablablabla.setVerticalAlignment(SwingConstants.BOTTOM);
		blablablabla.setBounds(67, 282, 246, 56);
		base.add(blablablabla);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(0, 27, 613, 33);
		base.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel_1.setBackground(new Color(0, 0, 139));
		panel_1.setBounds(0, 140, 313, 33);
		base.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel front = new JLabel("<html> \r\n\r\n<br>Front-End<br> <br>     \r\n");
		front.setHorizontalAlignment(SwingConstants.LEFT);
		front.setBounds(26, 0, 87, 33);
		panel_1.add(front);
		front.setForeground(new Color(255, 255, 255));
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel_3.setBackground(new Color(0, 0, 128));
		panel_3.setBounds(0, 239, 313, 33);
		base.add(panel_3);
		
		JLabel back = new JLabel("<html> \r\n\r\n<br>Back-End <br> <br>     </html>\r\n");
		back.setBounds(27, 0, 164, 33);
		panel_3.add(back);
		back.setForeground(new Color(255, 255, 255));
		back.setHorizontalAlignment(SwingConstants.LEFT);
		//coloque o nome dos outros caras que eu n�o sei :)//
		JPanel fundo = new JPanel();
		fundo.setBounds(0, 240, 663, 296);
		contentPane.add(fundo);
		fundo.setBackground(SystemColor.activeCaption);
		fundo.setLayout(null);
		
		JButton btnOkEntendi = new JButton("OK, entendi");
		btnOkEntendi.setBounds(260, 242, 119, 41);
		fundo.add(btnOkEntendi);
		btnOkEntendi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dispose();
			}
		});
	}
}
