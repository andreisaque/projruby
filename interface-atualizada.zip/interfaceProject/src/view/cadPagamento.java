package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;
import java.awt.Choice;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

public class cadPagamento extends JFrame {

	private JPanel contentPane;
	private JTextField txtCod;
	private JTextField txtNome;
	private JTextField txtValor;
	private JTextField txtNum_Pedido;
	private JTextField txtPesquisa;
	private JTable table;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
         } 
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
             System.err.println(ex);        
        } 		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cadPagamento frame = new cadPagamento();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public cadPagamento() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 686, 877);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel grade2 = new JPanel();
		grade2.setBounds(33, 480, 621, 316);
		grade2.setLayout(null);
		grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		contentPane.add(grade2);
		
		JButton bttalterar = new JButton("Alterar");
		bttalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttalterar.setBounds(312, 266, 120, 37);
		grade2.add(bttalterar);
		
		JButton bttremover = new JButton("Remover");
		bttremover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttremover.setBounds(456, 266, 120, 37);
		grade2.add(bttremover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setColumns(10);
		txtPesquisa.setBounds(23, 44, 243, 26);
		grade2.add(txtPesquisa);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade2.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade2.add(lblPesquisa);
		
		JScrollPane scrollzinhos2 = new JScrollPane();
		scrollzinhos2.setBounds(0, 84, 621, 139);
		grade2.add(scrollzinhos2);
		
		table = new JTable();
		table.setModel(new DefaultTableModel( //
			new Object[][] 
		    {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] 
			{ 
				"1", "2", "3", ":D"
			}
		));
		scrollzinhos2.setViewportView(table);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 702, 34);
		contentPane.add(menuBar);
		
		JMenu mnMenu = new JMenu("Menu |");
		menuBar.add(mnMenu);
		
		JMenuItem mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtNome.setText("");
				txtCod.setText("");
				txtNum_Pedido.setText("");
				txtValor.setText("");
				txtNum_Pedido.setText("");					
			}	
			
		});
		
		JMenuItem mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel grade1 = new JPanel();
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), null));
		grade1.setBounds(33, 93, 619, 354);
		contentPane.add(grade1);
		grade1.setLayout(null);
		
		txtCod = new JTextField();
		txtCod.setBounds(27, 69, 555, 24);
		grade1.add(txtCod);
		txtCod.setColumns(10);
		
		JLabel lblCod = new JLabel("C\u00F3digo");
		lblCod.setBounds(27, 50, 143, 16);
		grade1.add(lblCod);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(27, 106, 143, 16);
		grade1.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(27, 121, 555, 24);
		grade1.add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblValor = new JLabel("Valor");
		lblValor.setBounds(27, 150, 143, 16);
		grade1.add(lblValor);
		
		txtValor = new JTextField();
		txtValor.setBounds(27, 171, 130, 24);
		grade1.add(txtValor);
		txtValor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent a) {
				char c= a.getKeyChar();
				if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE))
				{
					a.consume(); 
				}
			}
		});
		txtValor.setColumns(10);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(205, 171, 157, 24);
		grade1.add(dateChooser);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(205, 150, 120, 16);
		grade1.add(lblData);
		
		Choice situacao = new Choice();
		situacao.setBounds(407, 173, 175, 22);
		grade1.add(situacao);
		
		JLabel lblSituacao = new JLabel("Situa\u00E7\u00E3o");
		lblSituacao.setBounds(407, 150, 56, 16);
		grade1.add(lblSituacao);
		
		JLabel lblNmeroDoPedido = new JLabel("N\u00FAmero do pedido");
		lblNmeroDoPedido.setBounds(27, 208, 143, 16);
		grade1.add(lblNmeroDoPedido);
		
		txtNum_Pedido = new JTextField();
		txtNum_Pedido.setBounds(27, 227, 555, 24);
		grade1.add(txtNum_Pedido);
		txtNum_Pedido.setColumns(10);
		
		JButton bttSalvar = new JButton("Salvar");
		bttSalvar.setBounds(320, 285, 120, 37);
		grade1.add(bttSalvar);
		
		JButton bttCancelar = new JButton("Cancelar");
		bttCancelar.setBounds(462, 285, 120, 37);
		grade1.add(bttCancelar);
		
		JPanel bg = new JPanel();
		bg.setBackground(SystemColor.activeCaption);
		bg.setBounds(0, 370, 715, 470);
		contentPane.add(bg);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(33, 47, 611, 33);
		contentPane.add(panel);
		
		JLabel lblPagamento = new JLabel("PAGAMENTO");
		lblPagamento.setForeground(Color.WHITE);
		lblPagamento.setFont(new Font("Arial", Font.PLAIN, 16));
		panel.add(lblPagamento);
		bttCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar?", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			
			}
		});
		bttSalvar.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg) 
			{
				//CtrlPagamento adicionar = new CtrlPagamento();FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, txtCod, txtValor, txt_Data, txtNome, txt_Descricao, situacao,txtNum_Pedido);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		situacao.add(">:(");
		situacao.add(">:)");
	}
}
