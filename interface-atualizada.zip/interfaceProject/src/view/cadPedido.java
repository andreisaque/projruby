package view;

import java.awt.Choice;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.Font;

public class cadPedido extends JFrame {

	private JPanel contentPane;
	private JTextField txtmatcli;
	private JTextField txtValor;
	private JTextField txtCod;
	private JTextField txtPesquisa;
	private JTable table;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cadPedido frame = new cadPedido();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public cadPedido() {
		setBackground(new Color(139, 0, 0));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 801);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menu = new JMenuBar();
		menu.setBounds(0, 0, 721, 33);
		contentPane.add(menu);
		
		JMenu mnNewMenu = new JMenu("Menu |");
		menu.add(mnNewMenu);
		
		JMenuItem optionNovo = new JMenuItem("Novo");
		mnNewMenu.add(optionNovo);
		optionNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtCod.setText("");
			    txtValor.setText("");
				txtmatcli.setText("");
				//txtPesquisa.setText("");	
			}	
			
		});		
		
		JMenuItem mntmVoltar = new JMenuItem("Voltar");
		mnNewMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		JMenuBar menuBar_1 = new JMenuBar();
		mnNewMenu.add(menuBar_1);
		
		JMenu mnAjuda = new JMenu("Ajuda");
		menu.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel grade1 = new JPanel();
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), null));
		grade1.setBounds(46, 88, 621, 293);
		contentPane.add(grade1);
		grade1.setLayout(null);
		
		txtCod = new JTextField();
		txtCod.setBounds(29, 68, 555, 22);
		grade1.add(txtCod);
		txtCod.setColumns(10);
		
		JLabel lblCodPedido = new JLabel("C\u00F3digo");
		lblCodPedido.setBounds(29, 49, 56, 16);
		grade1.add(lblCodPedido);
		
		JLabel txtDate = new JLabel("Data");
		txtDate.setBounds(29, 103, 120, 16);
		grade1.add(txtDate);
		
		JDateChooser datacalendario = new JDateChooser();
		datacalendario.setBounds(29, 121, 157, 24);
		grade1.add(datacalendario);
		
		txtValor = new JTextField();
		txtValor.setBounds(215, 123, 169, 22);
		grade1.add(txtValor);
		txtValor.setColumns(1);
		
		JLabel lblValor = new JLabel("Valor");
		lblValor.setBounds(215, 103, 56, 16);
		grade1.add(lblValor);
		
		Choice sit_choice = new Choice();
		sit_choice.setBounds(408, 123, 175, 22);
		grade1.add(sit_choice);
		
		JLabel lvlSituacao = new JLabel("Situa\u00E7\u00E3o");
		lvlSituacao.setBounds(408, 103, 56, 16);
		grade1.add(lvlSituacao);
		
		txtmatcli = new JTextField();
		txtmatcli.setBounds(29, 176, 555, 24);
		grade1.add(txtmatcli);
		txtmatcli.setColumns(1);
		
		JLabel lblmatcli = new JLabel("Matr\u00EDcula do Cliente");
		lblmatcli.setBounds(29, 158, 157, 16);
		grade1.add(lblmatcli);
		
		JButton bttSalvar = new JButton("Salvar");
		bttSalvar.setBounds(325, 213, 120, 37);
		grade1.add(bttSalvar);
		
		JButton bttCancelar = new JButton("Cancelar");
		bttCancelar.setBounds(464, 213, 120, 37);
		grade1.add(bttCancelar);
		bttCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos.", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			}
		});
		bttSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				//CtrlPedido adicionar = new CtrlPedido(); FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, txtCod, datacalendario, txtValor, lvlSituacao, txtmatcli);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		sit_choice.add(":))");
		sit_choice.add(":((");
		
		JPanel grade = new JPanel();
		grade.setLayout(null);
		grade.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		grade.setBounds(46, 405, 621, 316);
		contentPane.add(grade);
		
		JButton bttalterar = new JButton("Alterar");
		bttalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttalterar.setBounds(312, 266, 120, 37);
		grade.add(bttalterar);
		
		JButton bttremover = new JButton("Remover");
		bttremover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttremover.setBounds(456, 266, 120, 37);
		grade.add(bttremover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setColumns(10);
		txtPesquisa.setBounds(23, 44, 243, 26);
		grade.add(txtPesquisa);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade.add(lblPesquisa);
		
		JScrollPane scrolzinhoPane = new JScrollPane();
		scrolzinhoPane.setBounds(0, 88, 621, 128);
		grade.add(scrolzinhoPane);
		
		table = new JTable();
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"Ah mlk!", "Teste", "Outro teste", "Mais um teste"
			}
		));
		scrolzinhoPane.setViewportView(table);
		
		JPanel bg = new JPanel();
		bg.setBackground(SystemColor.activeCaption);
		bg.setBounds(-11, 357, 732, 409);
		contentPane.add(bg);
		
		JLabel lblPedido = new JLabel("PEDIDO");
		lblPedido.setForeground(new Color(255, 255, 255));
		lblPedido.setHorizontalAlignment(SwingConstants.CENTER);
		lblPedido.setFont(new Font("Arial", Font.PLAIN, 16));
		lblPedido.setBounds(273, 46, 124, 29);
		contentPane.add(lblPedido);
		
		JPanel pn_pedido_title = new JPanel();
		pn_pedido_title.setBackground(new Color(0, 0, 128));
		pn_pedido_title.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		pn_pedido_title.setBounds(46, 46, 621, 33);
		contentPane.add(pn_pedido_title);
	}
}
