package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.TextArea;
import java.awt.SystemColor;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

public class cadArmazem extends JFrame {

	private JPanel contentPane;
	private JTextField txtCod;
	private JTextField txtNomeArm;
	private JTextField txtEndArm;
	private JTextField txtPesquisa;
	private JTable table;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cadArmazem frame = new cadArmazem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public cadArmazem() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 721, 875);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel grade1 = new JPanel();
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), null));
		grade1.setBounds(46, 94, 621, 377);
		contentPane.add(grade1);
		grade1.setLayout(null);
		
		TextArea txtDescricao = new TextArea();
		txtDescricao.setRows(10);
		txtDescricao.setBounds(33, 212, 554, 82);
		grade1.add(txtDescricao);
		
		JButton buttonSalvar = new JButton("Salvar");
		buttonSalvar.setBounds(313, 315, 120, 37);
		grade1.add(buttonSalvar);
		
		JButton buttonCancelar = new JButton("Cancelar");
		buttonCancelar.setBounds(455, 315, 120, 37);
		grade1.add(buttonCancelar);
		
		JLabel lblDesc = new JLabel("Descri\u00E7\u00E3o");
		lblDesc.setBounds(33, 190, 56, 16);
		grade1.add(lblDesc);
		
		txtEndArm = new JTextField();
		txtEndArm.setBounds(33, 153, 555, 24);
		grade1.add(txtEndArm);
		txtEndArm.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o");
		lblEndereco.setBounds(33, 134, 56, 16);
		grade1.add(lblEndereco);
		
		txtNomeArm = new JTextField();
		txtNomeArm.setBounds(33, 99, 555, 24);
		grade1.add(txtNomeArm);
		txtNomeArm.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome ");
		lblNome.setBounds(33, 84, 143, 16);
		grade1.add(lblNome);
		
		txtCod = new JTextField();
		txtCod.setBounds(33, 47, 555, 24);
		grade1.add(txtCod);
		txtCod.setColumns(10);
		
		JLabel lblCod = new JLabel("C\u00F3digo");
		lblCod.setBounds(33, 28, 56, 16);
		grade1.add(lblCod);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 712, 31);
		contentPane.add(menuBar);
		
		JMenu mnMenu = new JMenu("Menu |");
		menuBar.add(mnMenu);
		
		JMenuItem mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtNomeArm.setText("");
				txtCod.setText("");
				txtEndArm.setText("");
				txtDescricao.setText(""); //esse nao esta funcionando :C
			}	
			
		});
		
		JMenuItem mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel bg = new JPanel();
		bg.setBackground(SystemColor.activeCaption);
		bg.setBounds(0, 356, 727, 506);
		contentPane.add(bg);
		bg.setLayout(null);
		
		JPanel grade2 = new JPanel();
		grade2.setBounds(47, 129, 621, 316);
		bg.add(grade2);
		grade2.setLayout(null);
		grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		
		JButton bttAlterar = new JButton("Alterar");
		bttAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttAlterar.setBounds(312, 266, 120, 37);
		grade2.add(bttAlterar);
		
		JButton bttRemover = new JButton("Remover");
		bttRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttRemover.setBounds(456, 266, 120, 37);
		grade2.add(bttRemover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setColumns(10);
		txtPesquisa.setBounds(23, 44, 243, 26);
		grade2.add(txtPesquisa);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade2.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade2.add(lblPesquisa);
		
		JScrollPane scroll = new JScrollPane();
		scroll.setBounds(0, 94, 621, 148);
		grade2.add(scroll);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] 
			{
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] 
			{
				"1", "2", "3", "4"
			}
		));
		scroll.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(46, 48, 621, 33);
		contentPane.add(panel);
		
		JLabel lblArmazm = new JLabel("ARMAZ\u00C9M");
		lblArmazm.setForeground(Color.WHITE);
		lblArmazm.setFont(new Font("Arial", Font.PLAIN, 16));
		panel.add(lblArmazm);
		buttonCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) {
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos.", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			}
		});
		buttonSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) 
			{
				//CtrlArmazem adicionar = new CtrlArmazem(); FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, txtCod, txtNomeArm, txtEndArm, txtDescricao);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}
}
