package model;

public class Armazem
{
  
  int codigo;
  String nome;
   String endereco;
   String descricao;

  public Armazem (int codigo, String nome, String endereco, String descricao)
  {
    this.codigo = codigo;
    this.nome = nome;
    this.endereco = endereco;
    this.descricao = descricao;
  }
}