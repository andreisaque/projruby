package model;

public class Item {

	  int sequencial;
	  int quantidade;
	  int produto_codigo;
	  int pedido_codigo;

	    public Item(int sequencial, int quantidade, int produto_codigo, int pedido_codigo)
	  {
	    this.sequencial = sequencial;
	    this.quantidade = quantidade;
	    this.produto_codigo = produto_codigo;
	    this.pedido_codigo = pedido_codigo;
	  }
}
