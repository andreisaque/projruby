package model;

public class Cliente_Juridico extends Cliente
{
  int cnpj;
   String razao_social;

  public Cliente_Juridico (int matricula, String nome, String contato, String endereco, String situacao, int cnpj, String razao_social)
  {
    super(matricula, nome, contato, endereco, situacao);
    this.cnpj = cnpj;
    this.razao_social = razao_social;
  }
}
