package model;

public class Produto {
	   int codigo;
	   String nome;
	   double preco;
	   String descricao;
	   String situacao;
	   int quantidade;
	   int armazem_codigo;
	   int fornecedor_cnpj;

	  public Produto(int codigo, String nome, double preco, String descricao, String situacao, int quantidade, int armazem_codigo, int fornecedor_cnpj)
	  {
	    this.codigo = codigo;
	    this. nome = nome;
	    this. preco = preco;
	    this. descricao = descricao;
	    this. situacao = situacao;
	    this. quantidade = quantidade;
	    this. armazem_codigo = armazem_codigo;
	    this. fornecedor_cnpj = fornecedor_cnpj;
	  }
}
