package model;

public class Pagamento
{
  int codigo;
  double valor;
  String data;
  String nome;
  String descricao;
  String situacao;
  int pedido_codigo;

    public Pagamento(int codigo, double valor, String data, String nome, String descricao, String situacao, int pedido_codigo)
  {
    this.codigo = codigo;
    this.valor = valor;
    this.data = data;
    this.nome = nome;
    this.descricao = descricao;
    this.situacao = situacao;
    this.pedido_codigo = pedido_codigo;
  }

}

